import React, { useState } from 'react'
import MainLeft from './MainLeft'
import MainRight from './MainRight'




const Main = () => {
  const [titleDescription , setTitleDescription ]= useState({});

  return (
    <main >
        <MainLeft setTitleDescription={setTitleDescription} />
        <MainRight titleDescription={titleDescription}/>
    </main>
    
  )
}

export default Main